import React, { createContext, useState, useContext, useEffect } from 'react';

const PortfolioContext = createContext();

export const usePortfolio = () => {
  const context = useContext(PortfolioContext);
  if (!context) {
    throw new Error('usePortfolio must be used within a PortfolioProvider');
  }
  return context;
};

export const PortfolioProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [portfolios, setPortfolios] = useState([]);
  const [currentPortfolio, setCurrentPortfolio] = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(null);
  const [theme, setTheme] = useState('light');

  // Load from localStorage on mount
  useEffect(() => {
    const savedUser = localStorage.getItem('portfolioUser');
    const savedPortfolios = localStorage.getItem('portfolios');
    const savedTheme = localStorage.getItem('theme');
    
    if (savedUser) setUser(JSON.parse(savedUser));
    if (savedPortfolios) setPortfolios(JSON.parse(savedPortfolios));
    if (savedTheme) setTheme(savedTheme);
  }, []);

  // Save to localStorage whenever data changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('portfolioUser', JSON.stringify(user));
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('portfolios', JSON.stringify(portfolios));
  }, [portfolios]);

  useEffect(() => {
    localStorage.setItem('theme', theme);
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const login = (username) => {
    setUser({ username, loggedInAt: new Date().toISOString() });
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('portfolioUser');
  };

  const savePortfolio = (portfolio) => {
    const portfolioWithId = {
      ...portfolio,
      id: portfolio.id || Date.now().toString(),
      updatedAt: new Date().toISOString(),
    };

    const existingIndex = portfolios.findIndex(p => p.id === portfolioWithId.id);
    if (existingIndex >= 0) {
      const updated = [...portfolios];
      updated[existingIndex] = portfolioWithId;
      setPortfolios(updated);
    } else {
      setPortfolios([...portfolios, portfolioWithId]);
    }
    
    setCurrentPortfolio(portfolioWithId);
  };

  const deletePortfolio = (id) => {
    setPortfolios(portfolios.filter(p => p.id !== id));
  };

  const toggleTheme = () => {
    setTheme(prev => prev === 'light' ? 'dark' : 'light');
  };

  const value = {
    user,
    portfolios,
    currentPortfolio,
    selectedTemplate,
    theme,
    login,
    logout,
    savePortfolio,
    deletePortfolio,
    setCurrentPortfolio,
    setSelectedTemplate,
    toggleTheme,
  };

  return (
    <PortfolioContext.Provider value={value}>
      {children}
    </PortfolioContext.Provider>
  );
};