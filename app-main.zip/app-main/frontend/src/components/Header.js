import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { usePortfolio } from '../context/PortfolioContext';
import { Moon, Sun, LogOut, User } from 'lucide-react';
import '../styles/Header.css';

const Header = () => {
  const { user, theme, toggleTheme, logout } = usePortfolio();
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  if (location.pathname === '/login') return null;

  return (
    <header className="app-header">
      <div className="header-container">
        <Link to="/dashboard" className="logo">
          <div className="logo-icon">P</div>
          <span className="logo-text">PortfolioBuilder</span>
        </Link>

        {user && (
          <nav className="nav-menu">
            <Link 
              to="/dashboard" 
              className={`nav-link ${location.pathname === '/dashboard' ? 'active' : ''}`}
            >
              Dashboard
            </Link>
            <Link 
              to="/create" 
              className={`nav-link ${location.pathname === '/create' ? 'active' : ''}`}
            >
              Create
            </Link>
            <Link 
              to="/templates" 
              className={`nav-link ${location.pathname === '/templates' ? 'active' : ''}`}
            >
              Templates
            </Link>
            <Link 
              to="/ai-suggestions" 
              className={`nav-link ${location.pathname === '/ai-suggestions' ? 'active' : ''}`}
            >
              AI Insights
            </Link>
          </nav>
        )}

        <div className="header-actions">
          <button onClick={toggleTheme} className="icon-btn" aria-label="Toggle theme">
            {theme === 'light' ? <Moon size={20} /> : <Sun size={20} />}
          </button>
          
          {user && (
            <>
              <div className="user-info">
                <User size={18} />
                <span>{user.username}</span>
              </div>
              <button onClick={handleLogout} className="icon-btn logout-btn" aria-label="Logout">
                <LogOut size={20} />
              </button>
            </>
          )}
        </div>
      </div>
    </header>
  );
};

export default Header;