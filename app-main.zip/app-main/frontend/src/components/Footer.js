import React from 'react';
import { Github, Twitter, Linkedin } from 'lucide-react';
import '../styles/Footer.css';

const Footer = () => {
  return (
    <footer className="app-footer">
      <div className="footer-container">
        <div className="footer-content">
          <div className="footer-section">
            <h3 className="footer-logo">PortfolioBuilder</h3>
            <p className="footer-tagline">Create stunning portfolios in minutes</p>
          </div>
          
          <div className="footer-section">
            <h4>Quick Links</h4>
            <ul className="footer-links">
              <li><a href="/about">About</a></li>
              <li><a href="/templates">Templates</a></li>
              <li><a href="#">Help Center</a></li>
            </ul>
          </div>
          
          <div className="footer-section">
            <h4>Connect</h4>
            <div className="social-links">
              <a href="#" aria-label="GitHub" className="social-icon">
                <Github size={20} />
              </a>
              <a href="#" aria-label="Twitter" className="social-icon">
                <Twitter size={20} />
              </a>
              <a href="#" aria-label="LinkedIn" className="social-icon">
                <Linkedin size={20} />
              </a>
            </div>
          </div>
        </div>
        
        <div className="footer-bottom">
          <p>&copy; 2024 PortfolioBuilder. Built for Hackathon Excellence.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;