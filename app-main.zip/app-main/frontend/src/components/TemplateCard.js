import React from 'react';
import { Check } from 'lucide-react';
import '../styles/TemplateCard.css';

const TemplateCard = ({ template, isSelected, onSelect }) => {
  return (
    <div 
      className={`template-card ${isSelected ? 'selected' : ''}`}
      onClick={() => onSelect(template)}
    >
      <div className="template-card-inner">
        <div className="template-card-front">
          <div className="template-image">
            <img src={template.preview} alt={template.name} />
            <div className="template-overlay">
              <div 
                className="color-indicator" 
                style={{
                  background: `linear-gradient(135deg, ${template.primaryColor} 0%, ${template.secondaryColor} 100%)`
                }}
              />
            </div>
          </div>
          <div className="template-info">
            <h3 className="template-name">{template.name}</h3>
            <span className="template-category">{template.category}</span>
          </div>
        </div>
        
        <div className="template-card-back">
          <div className="template-back-content">
            <h3>{template.name}</h3>
            <p>{template.description}</p>
            <div className="template-colors">
              <div 
                className="color-dot" 
                style={{ backgroundColor: template.primaryColor }}
              />
              <div 
                className="color-dot" 
                style={{ backgroundColor: template.secondaryColor }}
              />
            </div>
            <button className="select-btn">
              {isSelected ? (
                <>
                  <Check size={18} />
                  Selected
                </>
              ) : (
                'Select Template'
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TemplateCard;