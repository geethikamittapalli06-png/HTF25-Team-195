import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { PortfolioProvider } from './context/PortfolioContext';
import Header from './components/Header';
import Footer from './components/Footer';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Templates from './pages/Templates';
import Create from './pages/Create';
import AISuggestions from './pages/AISuggestions';
import './App.css';

function App() {
  return (
    <PortfolioProvider>
      <BrowserRouter>
        <div className="App">
          <Header />
          <main className="app-main">
            <Routes>
              <Route path="/login" element={<Login />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/templates" element={<Templates />} />
              <Route path="/create" element={<Create />} />
              <Route path="/ai-suggestions" element={<AISuggestions />} />
              <Route path="/" element={<Navigate to="/login" replace />} />
            </Routes>
          </main>
          <Footer />
        </div>
      </BrowserRouter>
    </PortfolioProvider>
  );
}

export default App;