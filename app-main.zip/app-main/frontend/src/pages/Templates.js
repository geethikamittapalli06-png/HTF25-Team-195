import React from 'react';
import { useNavigate } from 'react-router-dom';
import { usePortfolio } from '../context/PortfolioContext';
import TemplateCard from '../components/TemplateCard';
import { templates } from '../data/mockData';
import { ArrowRight } from 'lucide-react';
import '../styles/Templates.css';

const Templates = () => {
  const { selectedTemplate, setSelectedTemplate } = usePortfolio();
  const navigate = useNavigate();

  const handleSelect = (template) => {
    setSelectedTemplate(template);
  };

  const handleContinue = () => {
    if (selectedTemplate) {
      navigate('/create');
    }
  };

  const categories = ['all', 'developer', 'designer', 'marketer', 'general'];
  const [activeCategory, setActiveCategory] = React.useState('all');

  const filteredTemplates = activeCategory === 'all' 
    ? templates 
    : templates.filter(t => t.category === activeCategory);

  return (
    <div className="templates-page">
      <div className="templates-container">
        <div className="templates-header">
          <div className="header-content">
            <h1 className="page-title">Choose Your Template</h1>
            <p className="page-subtitle">
              Select a stunning template designed for your profession. 
              Hover to see details, click to select.
            </p>
          </div>
          
          <div className="category-filters">
            {categories.map(category => (
              <button
                key={category}
                className={`filter-btn ${activeCategory === category ? 'active' : ''}`}
                onClick={() => setActiveCategory(category)}
              >
                {category.charAt(0).toUpperCase() + category.slice(1)}
              </button>
            ))}
          </div>
        </div>
        
        <div className="templates-grid">
          {filteredTemplates.map(template => (
            <TemplateCard
              key={template.id}
              template={template}
              isSelected={selectedTemplate?.id === template.id}
              onSelect={handleSelect}
            />
          ))}
        </div>
        
        {selectedTemplate && (
          <div className="selection-banner">
            <div className="banner-content">
              <div className="selection-info">
                <span className="selection-label">Selected Template:</span>
                <span className="selection-name">{selectedTemplate.name}</span>
              </div>
              <button className="continue-btn" onClick={handleContinue}>
                Continue to Builder
                <ArrowRight size={20} />
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Templates;