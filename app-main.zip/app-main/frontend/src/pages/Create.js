import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { usePortfolio } from '../context/PortfolioContext';
import { dummyPortfolio } from '../data/mockData';
import { 
  Plus, 
  X, 
  Save, 
  Eye,
  Github,
  Linkedin,
  Twitter,
  Globe
} from 'lucide-react';
import '../styles/Create.css';

const Create = () => {
  const { currentPortfolio, savePortfolio, selectedTemplate } = usePortfolio();
  const navigate = useNavigate();
  const [formData, setFormData] = useState(currentPortfolio || dummyPortfolio);
  const [completionPercentage, setCompletionPercentage] = useState(0);

  useEffect(() => {
    calculateCompletion();
  }, [formData]);

  const calculateCompletion = () => {
    const fields = [
      formData.name,
      formData.profession,
      formData.bio,
      formData.email,
      formData.skills?.length > 0,
      formData.projects?.length > 0,
      formData.socialLinks?.github,
    ];
    const completed = fields.filter(Boolean).length;
    const percentage = Math.round((completed / fields.length) * 100);
    setCompletionPercentage(percentage);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSocialChange = (platform, value) => {
    setFormData(prev => ({
      ...prev,
      socialLinks: { ...prev.socialLinks, [platform]: value }
    }));
  };

  const addSkill = () => {
    setFormData(prev => ({
      ...prev,
      skills: [...(prev.skills || []), { name: '', level: 50 }]
    }));
  };

  const updateSkill = (index, field, value) => {
    const newSkills = [...formData.skills];
    newSkills[index][field] = value;
    setFormData(prev => ({ ...prev, skills: newSkills }));
  };

  const removeSkill = (index) => {
    setFormData(prev => ({
      ...prev,
      skills: prev.skills.filter((_, i) => i !== index)
    }));
  };

  const addProject = () => {
    setFormData(prev => ({
      ...prev,
      projects: [...(prev.projects || []), {
        id: Date.now(),
        title: '',
        description: '',
        technologies: [],
        link: '',
        image: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?w=400&h=300&fit=crop'
      }]
    }));
  };

  const updateProject = (index, field, value) => {
    const newProjects = [...formData.projects];
    newProjects[index][field] = value;
    setFormData(prev => ({ ...prev, projects: newProjects }));
  };

  const removeProject = (index) => {
    setFormData(prev => ({
      ...prev,
      projects: prev.projects.filter((_, i) => i !== index)
    }));
  };

  const handleSave = () => {
    savePortfolio(formData);
    alert('Portfolio saved successfully!');
  };

  const handlePreview = () => {
    savePortfolio(formData);
    navigate('/preview');
  };

  return (
    <div className="create-page">
      <div className="create-container">
        <div className="create-header">
          <div>
            <h1 className="page-title">Build Your Portfolio</h1>
            <p className="page-subtitle">
              Fill in your details to create a stunning portfolio
            </p>
          </div>
          <div className="header-actions">
            <div className="progress-indicator">
              <div className="progress-bar">
                <div 
                  className="progress-fill" 
                  style={{ width: `${completionPercentage}%` }}
                />
              </div>
              <span className="progress-text">{completionPercentage}% Complete</span>
            </div>
          </div>
        </div>

        <div className="form-layout">
          <div className="form-sections">
            {/* Basic Info */}
            <section className="form-section">
              <h2 className="section-title">Basic Information</h2>
              <div className="form-grid">
                <div className="form-group">
                  <label>Full Name *</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    placeholder="John Doe"
                  />
                </div>
                <div className="form-group">
                  <label>Profession *</label>
                  <input
                    type="text"
                    name="profession"
                    value={formData.profession}
                    onChange={handleInputChange}
                    placeholder="Full Stack Developer"
                  />
                </div>
                <div className="form-group">
                  <label>Email *</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleInputChange}
                    placeholder="john@example.com"
                  />
                </div>
                <div className="form-group">
                  <label>Phone</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    placeholder="+1 (555) 123-4567"
                  />
                </div>
              </div>
              <div className="form-group full-width">
                <label>About Me *</label>
                <textarea
                  name="bio"
                  value={formData.bio}
                  onChange={handleInputChange}
                  placeholder="Tell us about yourself, your experience, and what you're passionate about..."
                  rows={4}
                />
              </div>
            </section>

            {/* Skills */}
            <section className="form-section">
              <div className="section-header">
                <h2 className="section-title">Skills</h2>
                <button onClick={addSkill} className="add-btn">
                  <Plus size={18} />
                  Add Skill
                </button>
              </div>
              <div className="skills-list">
                {formData.skills?.map((skill, index) => (
                  <div key={index} className="skill-item">
                    <input
                      type="text"
                      value={skill.name}
                      onChange={(e) => updateSkill(index, 'name', e.target.value)}
                      placeholder="Skill name"
                      className="skill-input"
                    />
                    <div className="skill-level">
                      <input
                        type="range"
                        min="0"
                        max="100"
                        value={skill.level}
                        onChange={(e) => updateSkill(index, 'level', parseInt(e.target.value))}
                        className="level-slider"
                      />
                      <span className="level-value">{skill.level}%</span>
                    </div>
                    <button onClick={() => removeSkill(index)} className="remove-btn">
                      <X size={18} />
                    </button>
                  </div>
                ))}
              </div>
            </section>

            {/* Projects */}
            <section className="form-section">
              <div className="section-header">
                <h2 className="section-title">Projects</h2>
                <button onClick={addProject} className="add-btn">
                  <Plus size={18} />
                  Add Project
                </button>
              </div>
              <div className="projects-list">
                {formData.projects?.map((project, index) => (
                  <div key={project.id} className="project-card">
                    <div className="project-header">
                      <h3>Project {index + 1}</h3>
                      <button onClick={() => removeProject(index)} className="remove-btn">
                        <X size={18} />
                      </button>
                    </div>
                    <div className="form-grid">
                      <div className="form-group">
                        <label>Title</label>
                        <input
                          type="text"
                          value={project.title}
                          onChange={(e) => updateProject(index, 'title', e.target.value)}
                          placeholder="Project name"
                        />
                      </div>
                      <div className="form-group">
                        <label>Link</label>
                        <input
                          type="url"
                          value={project.link}
                          onChange={(e) => updateProject(index, 'link', e.target.value)}
                          placeholder="https://github.com/..."
                        />
                      </div>
                    </div>
                    <div className="form-group">
                      <label>Description</label>
                      <textarea
                        value={project.description}
                        onChange={(e) => updateProject(index, 'description', e.target.value)}
                        placeholder="Describe your project..."
                        rows={3}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* Social Links */}
            <section className="form-section">
              <h2 className="section-title">Social Links</h2>
              <div className="social-inputs">
                <div className="form-group">
                  <label>
                    <Github size={18} />
                    GitHub
                  </label>
                  <input
                    type="url"
                    value={formData.socialLinks?.github || ''}
                    onChange={(e) => handleSocialChange('github', e.target.value)}
                    placeholder="https://github.com/username"
                  />
                </div>
                <div className="form-group">
                  <label>
                    <Linkedin size={18} />
                    LinkedIn
                  </label>
                  <input
                    type="url"
                    value={formData.socialLinks?.linkedin || ''}
                    onChange={(e) => handleSocialChange('linkedin', e.target.value)}
                    placeholder="https://linkedin.com/in/username"
                  />
                </div>
                <div className="form-group">
                  <label>
                    <Twitter size={18} />
                    Twitter
                  </label>
                  <input
                    type="url"
                    value={formData.socialLinks?.twitter || ''}
                    onChange={(e) => handleSocialChange('twitter', e.target.value)}
                    placeholder="https://twitter.com/username"
                  />
                </div>
                <div className="form-group">
                  <label>
                    <Globe size={18} />
                    Portfolio Website
                  </label>
                  <input
                    type="url"
                    value={formData.socialLinks?.portfolio || ''}
                    onChange={(e) => handleSocialChange('portfolio', e.target.value)}
                    placeholder="https://yoursite.com"
                  />
                </div>
              </div>
            </section>
          </div>

          {/* Action Buttons */}
          <div className="action-buttons">
            <button onClick={handleSave} className="save-btn">
              <Save size={20} />
              Save Portfolio
            </button>
            <button onClick={handlePreview} className="preview-btn">
              <Eye size={20} />
              Preview & Download
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Create;