import React from 'react';
import { useNavigate } from 'react-router-dom';
import { usePortfolio } from '../context/PortfolioContext';
import { 
  Plus, 
  Briefcase, 
  Sparkles, 
  FileText, 
  TrendingUp,
  Zap
} from 'lucide-react';
import '../styles/Dashboard.css';

const Dashboard = () => {
  const { portfolios, user } = usePortfolio();
  const navigate = useNavigate();

  const cards = [
    {
      title: 'Create Portfolio',
      description: 'Build a new portfolio from scratch with our intuitive builder',
      icon: Plus,
      gradient: 'linear-gradient(135deg, #667eea 0%, #764ba2 100%)',
      path: '/create',
      action: 'Start Building',
    },
    {
      title: 'My Portfolios',
      description: `You have ${portfolios.length} portfolio${portfolios.length !== 1 ? 's' : ''} ready to showcase`,
      icon: Briefcase,
      gradient: 'linear-gradient(135deg, #89f7fe 0%, #66a6ff 100%)',
      path: '/my-portfolios',
      action: 'View All',
      count: portfolios.length,
    },
    {
      title: 'Choose Template',
      description: 'Browse 10+ stunning templates designed for different professions',
      icon: FileText,
      gradient: 'linear-gradient(135deg, #a8edea 0%, #fed6e3 100%)',
      path: '/templates',
      action: 'Explore',
    },
    {
      title: 'AI Suggestions',
      description: 'Get personalized insights to improve your portfolio with AI',
      icon: Sparkles,
      gradient: 'linear-gradient(135deg, #fbc2eb 0%, #a6c1ee 100%)',
      path: '/ai-suggestions',
      action: 'Get Insights',
    },
  ];

  const stats = [
    { label: 'Portfolios', value: portfolios.length, icon: Briefcase },
    { label: 'Completion', value: '87%', icon: TrendingUp },
    { label: 'ATS Score', value: '87/100', icon: Zap },
  ];

  return (
    <div className="dashboard-page">
      <div className="dashboard-container">
        <div className="dashboard-header">
          <div className="welcome-section">
            <h1 className="dashboard-title">
              Welcome back, <span className="gradient-text">{user?.username}</span>
            </h1>
            <p className="dashboard-subtitle">
              Let's create something amazing today
            </p>
          </div>
          
          <div className="stats-grid">
            {stats.map((stat, index) => (
              <div key={index} className="stat-card">
                <div className="stat-icon">
                  <stat.icon size={20} />
                </div>
                <div className="stat-content">
                  <div className="stat-value">{stat.value}</div>
                  <div className="stat-label">{stat.label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="action-cards">
          {cards.map((card, index) => {
            const Icon = card.icon;
            return (
              <div 
                key={index} 
                className="action-card"
                onClick={() => navigate(card.path)}
                style={{
                  animationDelay: `${index * 0.1}s`
                }}
              >
                <div className="card-glow" style={{ background: card.gradient }} />
                <div className="card-content">
                  <div 
                    className="card-icon"
                    style={{ background: card.gradient }}
                  >
                    <Icon size={28} />
                  </div>
                  
                  <div className="card-text">
                    <h3 className="card-title">
                      {card.title}
                      {card.count !== undefined && (
                        <span className="card-badge">{card.count}</span>
                      )}
                    </h3>
                    <p className="card-description">{card.description}</p>
                  </div>
                  
                  <button 
                    className="card-action"
                    style={{ background: card.gradient }}
                  >
                    {card.action}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
        
        <div className="quick-tips">
          <h2 className="tips-title">Quick Tips</h2>
          <div className="tips-grid">
            <div className="tip-item">
              <Sparkles className="tip-icon" size={20} />
              <p>Use AI suggestions to optimize your portfolio for ATS systems</p>
            </div>
            <div className="tip-item">
              <FileText className="tip-icon" size={20} />
              <p>Choose templates that match your profession for best results</p>
            </div>
            <div className="tip-item">
              <TrendingUp className="tip-icon" size={20} />
              <p>Update your projects regularly to keep your portfolio fresh</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;