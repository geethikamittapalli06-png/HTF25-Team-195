import React from 'react';
import { aiSuggestions } from '../data/mockData';
import { 
  TrendingUp, 
  AlertCircle, 
  Lightbulb, 
  Award,
  CheckCircle,
  Target
} from 'lucide-react';
import '../styles/AISuggestions.css';

const AISuggestions = () => {
  const { strengths, weaknesses, recommendations, atsScore, atsBreakdown } = aiSuggestions;

  const getScoreColor = (score) => {
    if (score >= 80) return '#10b981';
    if (score >= 60) return '#f59e0b';
    return '#ef4444';
  };

  const getScoreGrade = (score) => {
    if (score >= 90) return 'Excellent';
    if (score >= 80) return 'Very Good';
    if (score >= 70) return 'Good';
    if (score >= 60) return 'Fair';
    return 'Needs Improvement';
  };

  return (
    <div className="ai-suggestions-page">
      <div className="ai-container">
        <div className="ai-header">
          <div className="header-icon">
            <Target size={32} />
          </div>
          <h1 className="page-title">AI-Powered Portfolio Insights</h1>
          <p className="page-subtitle">
            Get personalized suggestions to optimize your portfolio for recruiters and ATS systems
          </p>
        </div>

        {/* ATS Score Section */}
        <div className="score-section">
          <div className="score-card main-score">
            <div className="score-header">
              <Award size={28} />
              <h2>Overall ATS Score</h2>
            </div>
            <div className="score-display">
              <div className="score-circle">
                <svg viewBox="0 0 200 200" className="score-ring">
                  <circle
                    cx="100"
                    cy="100"
                    r="90"
                    fill="none"
                    stroke="rgba(102, 126, 234, 0.1)"
                    strokeWidth="12"
                  />
                  <circle
                    cx="100"
                    cy="100"
                    r="90"
                    fill="none"
                    stroke={getScoreColor(atsScore)}
                    strokeWidth="12"
                    strokeDasharray={`${(atsScore / 100) * 565.48} 565.48`}
                    strokeLinecap="round"
                    transform="rotate(-90 100 100)"
                  />
                </svg>
                <div className="score-value">
                  <span className="score-number">{atsScore}</span>
                  <span className="score-total">/100</span>
                </div>
              </div>
              <div className="score-info">
                <div className="score-grade" style={{ color: getScoreColor(atsScore) }}>
                  {getScoreGrade(atsScore)}
                </div>
                <p className="score-description">
                  Your portfolio is well-optimized for Applicant Tracking Systems (ATS).
                  Keep up the good work!
                </p>
              </div>
            </div>
          </div>

          <div className="score-breakdown">
            <h3>Score Breakdown</h3>
            <div className="breakdown-items">
              {Object.entries(atsBreakdown).map(([category, score]) => (
                <div key={category} className="breakdown-item">
                  <div className="breakdown-header">
                    <span className="breakdown-label">{category}</span>
                    <span className="breakdown-value" style={{ color: getScoreColor(score) }}>
                      {score}%
                    </span>
                  </div>
                  <div className="breakdown-bar">
                    <div 
                      className="breakdown-fill" 
                      style={{ 
                        width: `${score}%`,
                        background: getScoreColor(score)
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Suggestions Grid */}
        <div className="suggestions-grid">
          {/* Strengths */}
          <div className="suggestion-card strengths-card">
            <div className="card-header">
              <div className="card-icon success">
                <CheckCircle size={24} />
              </div>
              <h2>Strengths</h2>
            </div>
            <ul className="suggestion-list">
              {strengths.map((strength, index) => (
                <li key={index} className="suggestion-item">
                  <TrendingUp size={18} className="item-icon success" />
                  <span>{strength}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Areas for Improvement */}
          <div className="suggestion-card weaknesses-card">
            <div className="card-header">
              <div className="card-icon warning">
                <AlertCircle size={24} />
              </div>
              <h2>Areas for Improvement</h2>
            </div>
            <ul className="suggestion-list">
              {weaknesses.map((weakness, index) => (
                <li key={index} className="suggestion-item">
                  <AlertCircle size={18} className="item-icon warning" />
                  <span>{weakness}</span>
                </li>
              ))}
            </ul>
          </div>

          {/* Recommendations */}
          <div className="suggestion-card recommendations-card">
            <div className="card-header">
              <div className="card-icon info">
                <Lightbulb size={24} />
              </div>
              <h2>AI Recommendations</h2>
            </div>
            <ul className="suggestion-list">
              {recommendations.map((recommendation, index) => (
                <li key={index} className="suggestion-item">
                  <Lightbulb size={18} className="item-icon info" />
                  <span>{recommendation}</span>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* AI Feature Badges */}
        <div className="ai-features">
          <div className="feature-badge">
            <div className="badge-icon">🤖</div>
            <div className="badge-content">
              <h4>AI Text Enhancement</h4>
              <p>Suggests improved bio and about me text</p>
            </div>
          </div>
          <div className="feature-badge">
            <div className="badge-icon">🎨</div>
            <div className="badge-content">
              <h4>Template Recommender</h4>
              <p>Suggests best design based on profession</p>
            </div>
          </div>
          <div className="feature-badge">
            <div className="badge-icon">📊</div>
            <div className="badge-content">
              <h4>ATS Optimization</h4>
              <p>Analyzes compatibility with hiring systems</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AISuggestions;